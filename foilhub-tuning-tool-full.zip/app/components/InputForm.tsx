"use client";

import type { SetupInput } from "../../lib/calc";
import { DISCIPLINES, GOALS, CONDITIONS } from "../../lib/presets";

export default function InputForm({
  value,
  onChange
}: {
  value: SetupInput;
  onChange: (v: SetupInput) => void;
}) {
  function update(patch: Partial<SetupInput>) {
    onChange({ ...value, ...patch });
  }

  return (
    <section className="bg-white rounded-2xl shadow-soft border border-foilhub-mist p-4 space-y-4">
      <h2 className="font-bold text-lg">Your Setup</h2>

      <div className="grid grid-cols-2 gap-3">
        <label className="space-y-1">
          <div className="text-xs font-semibold text-black/60">Rider weight (kg)</div>
          <input
            className="w-full rounded-xl border border-foilhub-mist px-3 py-2"
            type="number"
            min={30}
            max={140}
            value={value.riderKg}
            onChange={(e) => update({ riderKg: Number(e.target.value) })}
          />
        </label>

        <label className="space-y-1">
          <div className="text-xs font-semibold text-black/60">Discipline</div>
          <select
            className="w-full rounded-xl border border-foilhub-mist px-3 py-2"
            value={value.discipline}
            onChange={(e) => update({ discipline: e.target.value as any })}
          >
            {DISCIPLINES.map((d) => (
              <option key={d.value} value={d.value}>{d.label}</option>
            ))}
          </select>
        </label>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <label className="space-y-1">
          <div className="text-xs font-semibold text-black/60">Front wing area (cm²)</div>
          <input
            className="w-full rounded-xl border border-foilhub-mist px-3 py-2"
            type="number"
            min={300}
            max={2500}
            value={value.frontAreaCm2}
            onChange={(e) => update({ frontAreaCm2: Number(e.target.value) })}
          />
        </label>

        <label className="space-y-1">
          <div className="text-xs font-semibold text-black/60">Front wing AR</div>
          <input
            className="w-full rounded-xl border border-foilhub-mist px-3 py-2"
            type="number"
            step="0.1"
            min={3}
            max={12}
            value={value.frontAR}
            onChange={(e) => update({ frontAR: Number(e.target.value) })}
          />
        </label>
      </div>

      <div className="grid grid-cols-3 gap-3">
        <label className="space-y-1">
          <div className="text-xs font-semibold text-black/60">Stab size (cm²)</div>
          <input
            className="w-full rounded-xl border border-foilhub-mist px-3 py-2"
            type="number"
            min={120}
            max={800}
            value={value.stabAreaCm2}
            onChange={(e) => update({ stabAreaCm2: Number(e.target.value) })}
          />
        </label>

        <label className="space-y-1">
          <div className="text-xs font-semibold text-black/60">Mast length (cm)</div>
          <input
            className="w-full rounded-xl border border-foilhub-mist px-3 py-2"
            type="number"
            min={55}
            max={115}
            value={value.mastCm}
            onChange={(e) => update({ mastCm: Number(e.target.value) })}
          />
        </label>

        <label className="space-y-1">
          <div className="text-xs font-semibold text-black/60">Fuse length (cm)</div>
          <input
            className="w-full rounded-xl border border-foilhub-mist px-3 py-2"
            type="number"
            min={55}
            max={85}
            value={value.fuseCm}
            onChange={(e) => update({ fuseCm: Number(e.target.value) })}
          />
        </label>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <label className="space-y-1">
          <div className="text-xs font-semibold text-black/60">Board volume (L)</div>
          <input
            className="w-full rounded-xl border border-foilhub-mist px-3 py-2"
            type="number"
            min={10}
            max={200}
            value={value.boardLiters}
            onChange={(e) => update({ boardLiters: Number(e.target.value) })}
          />
        </label>

        <label className="space-y-1">
          <div className="text-xs font-semibold text-black/60">Condition</div>
          <select
            className="w-full rounded-xl border border-foilhub-mist px-3 py-2"
            value={value.condition}
            onChange={(e) => update({ condition: e.target.value })}
          >
            {CONDITIONS.map((c) => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
        </label>
      </div>

      <label className="space-y-1">
        <div className="text-xs font-semibold text-black/60">Goal / issue</div>
        <select
          className="w-full rounded-xl border border-foilhub-mist px-3 py-2"
          value={value.goal}
          onChange={(e) => update({ goal: e.target.value as any })}
        >
          {GOALS.map((g) => (
            <option key={g.value} value={g.value}>{g.label}</option>
          ))}
        </select>
      </label>

      <label className="space-y-1">
        <div className="text-xs font-semibold text-black/60">
          Current track position (cm from tail) — optional
        </div>
        <input
          className="w-full rounded-xl border border-foilhub-mist px-3 py-2"
          type="number"
          min={0}
          max={70}
          placeholder="leave blank if unknown"
          value={value.trackFromTailCm ?? ""}
          onChange={(e) =>
            update({ trackFromTailCm: e.target.value ? Number(e.target.value) : null })
          }
        />
      </label>

      <div className="text-xs text-black/50">
        FoilHub note: results are estimates based on typical lift curves by area/AR and discipline.
      </div>
    </section>
  );
}
