"use client";

import type { SetupInput, SetupOutput } from "../../lib/calc";
import LiftChart from "./LiftChart";

export default function ResultsPanel({
  input,
  results
}: {
  input: SetupInput;
  results: SetupOutput;
}) {
  return (
    <section className="bg-white rounded-2xl shadow-soft border border-foilhub-mist p-4 space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="font-bold text-lg">Recommendations</h2>
        <div className="text-xs px-2 py-1 rounded-full bg-foilhub-mist">
          FoilHub Engine v1
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <Card title="Track Position">
          <div className="text-2xl font-black text-foilhub-ocean">
            {results.trackFromTailCm.toFixed(1)} cm
          </div>
          <div className="text-xs text-black/60">
            from tail (center of mast)
          </div>
        </Card>

        <Card title="Shim Suggestion">
          <div className="text-2xl font-black text-foilhub-green">
            {results.shimDeg > 0 ? "+" : ""}{results.shimDeg.toFixed(1)}°
          </div>
          <div className="text-xs text-black/60">
            {results.shimNote}
          </div>
        </Card>
      </div>

      <Card title="Pressure Bias">
        <div className="font-semibold">{results.pressureBias}</div>
        <div className="text-xs text-black/60">{results.pressureNote}</div>
      </Card>

      <div className="grid grid-cols-3 gap-3">
        <Score title="Pump Score" v={results.pumpScore} />
        <Score title="Turning Score" v={results.turnScore} />
        <Score title="Speed Stability" v={results.speedScore} />
      </div>

      <Card title="Lift Curve (estimated)">
        <LiftChart points={results.liftCurve} />
        <div className="text-xs text-black/60 mt-2">
          Takeoff predicted at ~{results.takeoffMph.toFixed(1)} mph.
        </div>
      </Card>

      <Card title="Quick Notes">
        <ul className="list-disc pl-5 text-sm space-y-1">
          {results.notes.map((n, i) => <li key={i}>{n}</li>)}
        </ul>
      </Card>
    </section>
  );
}

function Card({ title, children }: any) {
  return (
    <div className="rounded-xl border border-foilhub-mist p-3 space-y-1">
      <div className="text-xs font-bold text-black/60">{title}</div>
      {children}
    </div>
  );
}

function Score({ title, v }: { title: string; v: number }) {
  return (
    <div className="rounded-xl border border-foilhub-mist p-3">
      <div className="text-xs font-bold text-black/60">{title}</div>
      <div className="text-2xl font-black">{v}</div>
      <div className="h-2 bg-foilhub-mist rounded-full mt-2 overflow-hidden">
        <div
          className="h-full bg-foilhub-sea"
          style={{ width: `${v}%` }}
        />
      </div>
    </div>
  );
}
