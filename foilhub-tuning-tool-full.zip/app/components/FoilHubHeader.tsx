export default function FoilHubHeader() {
  return (
    <header className="sticky top-0 z-10 bg-white/80 backdrop-blur border-b border-foilhub-mist">
      <div className="max-w-6xl mx-auto px-4 py-3 flex items-center gap-3">
        <div className="h-9 w-9 rounded-xl bg-foilhub-ocean text-white grid place-items-center font-black">
          FH
        </div>
        <div>
          <h1 className="text-lg font-bold leading-none">FoilHub Tuning Tool</h1>
          <p className="text-xs text-black/60">Setup • Track • Shim • Lift Curve</p>
        </div>
      </div>
    </header>
  );
}
